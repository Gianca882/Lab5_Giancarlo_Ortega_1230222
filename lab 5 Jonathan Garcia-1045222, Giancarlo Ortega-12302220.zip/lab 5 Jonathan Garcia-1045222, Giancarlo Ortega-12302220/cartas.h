#pragma once
#include <string>
using namespace std;

struct cartas

{

	string numero;
	string color;



	cartas* next;

};
